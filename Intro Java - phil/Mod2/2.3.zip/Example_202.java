/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 */
/*
 * Runtime Error
 */
public class Example_202{

  // This placement of the []s is allowed
  public static void main(String args []){

    System.out.println(100 / 0); // Throws a runtime error (Exception)
  }
}