/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 */
/*
 * Error Correction
 */
public class Example_205{

  public static void main(String [] args){

    System.out.println("In the preceding chapter, you learned how to create, " +
                       "compile, and run a Java program. Starting from this chapter, " + 
                       "you will learn how to solve practical problems programmatically. " + 
                       "Through these problems, you will learn Java primitive data types " +
                       "and related subjects, such as variables, constants, data types, " +
                       "operators, expressions, and input and output.");
  }
}