/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 */
/*
 * Syntax Error
 */
public class Example_201{

  // Missing key word, return type 'void'
  public static main(String [] args){

    System.out.println("Hello World") // Missing ;
  }
}