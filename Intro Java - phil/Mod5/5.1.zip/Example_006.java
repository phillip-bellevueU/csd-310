/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 * Placement of the {}s
 */
public class Example_006{

  public static void main(String [] args){

    int i = 0;

    while(i < 50){

      System.out.println("Java Statement");
      ++i;
    }
  }
}