/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 */
/*
 * Something we should avoid?
 *
 * A bad practice?
 */
public class Example_004{

  public static void main(String [] args){

    int i = 0;

    while(i++ < 5)

      System.out.println("Hello World");
  }
}