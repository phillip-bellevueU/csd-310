/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 * Placement of the {}s
 */
/*
 * What does this code do?  Why?
 */
public class Example_005{

  public static void main(String [] args){

    int i = 0;

    while(i < 5);
    {
      System.out.println("Hello World");
      ++i;
    }
  }
}