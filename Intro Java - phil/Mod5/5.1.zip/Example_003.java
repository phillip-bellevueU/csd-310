/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 */
/*
 * What does this code do?  Why?
 */
public class Example_003{

  public static void main(String [] args){

    int i = 0;

    while(i < 5)

      System.out.println("Hello World");
      ++i;
  }
}