/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 * Missing ()s
 */
/*
 * Error
 */
public class Example_007{

  public static void main(String [] args){

    int i = 0;

    // ()s are required
    while i < 100 {

      System.out.println("Java Statement");
      ++i;
    }
  }
}