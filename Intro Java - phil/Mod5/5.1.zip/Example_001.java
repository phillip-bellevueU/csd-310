/*
 *
 * Professor Darrell Payne
 * Bellevue University
 *
 */
/*
 * Print "Hello World" 5 times
 */
public class Example_001{

  public static void main(String [] args){

    System.out.println("Hello World");
    System.out.println("Hello World");
    System.out.println("Hello World");
    System.out.println("Hello World");
    System.out.println("Hello World");
  }
}